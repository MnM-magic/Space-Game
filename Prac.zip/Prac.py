import pygame
import random
#from os.path import join#for joinnig paths for images)
# general setup

pygame.init()
WINDOW_WIDTH, Window_HEIGHT = 1280,720

class stars(pygame.sprite.Sprite):
    def __init__(self,groups,surf):
        super().__init__(groups)
        self.image=surf

    def update(self):
        self.rect=self.image.get_frect(center=(random.randint(0,WINDOW_WIDTH),random.randint(0,Window_HEIGHT)))
        if self.rect.bottom<0:
            self.kill()

class meteor(pygame.sprite.Sprite):
    def __init__(self,surf,pos, groups):
        super().__init__(groups)
        self.image=surf
        self.rect=self.image.get_frect(center = pos)
        self.start_time = pygame.time.get_ticks()
        self.lifetime = 3000
        self.direction= pygame.Vector2(random.uniform(-0.5,0.5),1)
        self.speed=random.randint(400,500)
    def update(self,dt):
        self.rect.center+=self.direction
        if pygame.time.get_ticks() - self.start_time >= self.lifetime:
            self.kill()  
        if score == 33:
            self.speed=self.speed*2  
                            
class laser(pygame.sprite.Sprite):
    def __init__(self,surf,pos,groups):
        super().__init__(groups)
        self.image=surf
        self.rect = self.image.get_frect(midbottom = pos)

    def update(self,dt):
        self.rect.centery-=200*dt
        if self.rect.bottom<0:
            self.kill()

class Plane(pygame.sprite.Sprite):
    def __init__(self,groups):
        global score
        score=0
        #plane display through sprite
        super().__init__(groups)
        self.image=pygame.image.load("../images/player.png").convert_alpha()
        self.rect=self.image.get_frect(center=(WINDOW_WIDTH/2,Window_HEIGHT/2))
        self.direct=pygame.Vector2( )
        self.speed=250
        
        #cooldown
        self.can_shoot=True
        self.laser_shoot_timer = 0
        self.cooldown_duration=400
        
    def laser_timer(self):
        if not self.can_shoot:
            current_time=pygame.time.get_ticks()
            if current_time-self.laser_shoot_time >=self.cooldown_duration:
                self.can_shoot = True
    
    def update(self,dt):
        #input
        keys=pygame.key.get_pressed()
        self.direct.x=int(keys[pygame.K_RIGHT])-int(keys[pygame.K_LEFT])
        self.direct.y=int(keys[pygame.K_DOWN])-int(keys[pygame.K_UP])
        self.direct=self.direct.normalize() if self.direct else self.direct
        self.rect.center+=self.direct*self.speed*dt 
        recent_key= pygame.key.get_just_pressed()
        
        if score==6:
            self.image=pygame.image.load("../images/Ships.png").convert_alpha()
        if score==33:
            self.image=pygame.image.load("../images/My one day.jpg").convert_alpha()
        if recent_key[pygame.K_SPACE] and self.can_shoot: 
            laser(laser_surface,self.rect.midtop,(all_sprites,Laser_sprites))
            self.can_shoot=False
            self.laser_shoot_time = pygame.time.get_ticks()
        self.laser_timer()

def collision():
    global running
    global score
    collided_sprites=pygame.sprite.spritecollide(plane,meteor_sprites,True)
    
    if collided_sprites:
       score-=10
    
    if score<0:
        running=False      
    
    for Laser in Laser_sprites:
        collided_sprites = pygame.sprite.spritecollide(Laser,meteor_sprites,True)

        if collided_sprites:
            score+=3
            Laser.kill() 

def Numbers_font():
      
    #score
    score_surf=Score_font.render(str(score), True,(222,222,222))
    score_rect=score_surf.get_frect(midbottom = (WINDOW_WIDTH-80,Window_HEIGHT-50))
    display_surface.blit(score_surf,score_rect)
    
    #word
    word_surf=text_font.render("Shots on target", True,(222,222,222))
    word_rect=word_surf.get_frect(midtop = (WINDOW_WIDTH-80,Window_HEIGHT-50))
    display_surface.blit(word_surf,word_rect)
    #time
    current_timer=pygame.time.get_ticks()//10
    text_surf=time_font.render(str(current_timer), True,(222,222,222))
    text_rect=text_surf.get_frect(midbottom = (WINDOW_WIDTH/2,Window_HEIGHT-50))
    display_surface.blit(text_surf,text_rect)
    #distance
    Distance_surf=Dist_font.render("Distance", True,(222,222,222))
    Distance_rect=Distance_surf.get_frect(midbottom = (WINDOW_WIDTH/2,Window_HEIGHT-20))
    display_surface.blit(Distance_surf,Distance_rect)
    #borders
    pygame.draw.rect(display_surface,(222,222,222),text_rect.inflate(20,10).move(0,-8),5,15)
    
#background  
display_surface =pygame.display.set_mode((WINDOW_WIDTH, Window_HEIGHT),pygame.RESIZABLE)
surface=pygame.Surface((100,200))
running = True

#imports
star_surf = pygame.image.load("../images/star.png").convert_alpha()
Meteor =pygame.image.load("../images/meteor.png").convert_alpha()
laser_surface=pygame.image.load("../images/laser.png").convert_alpha()

#font
time_font=pygame.font.Font("../images/almonte/almonte woodgrain.ttf",40)
Score_font=pygame.font.Font("../images/almonte/almonte snow.ttf",50)
text_font=pygame.font.Font("../images/almonte/almonte.ttf",20)
Dist_font=pygame.font.Font("../images/almonte/almonte.ttf",20)
 #sprites
all_sprites=pygame.sprite.Group()
star_sprites=pygame.sprite.Group()
meteor_sprites=pygame.sprite.Group()
Laser_sprites=pygame.sprite.Group()

#logo icon
pygame.display.set_caption("Battle front")
img = pygame.image.load("../images/pixil-frame-0.png")
print(img)
pygame. display. set_icon(img)

plane=Plane(all_sprites)
for i in range(20):
    stars(star_sprites, star_surf)
speed = 500
 
#custom event -> metor
Meteor_event=pygame.event.custom_type()
pygame.time.set_timer(Meteor_event,speed)
Star_time=pygame.event.custom_type()
clock=pygame.time.Clock()

'''x=100
z=0
i=0'''

#surface with image
#Plane_surface=pygame.image.load("../images/player.png").convert_alpha()
#or Plane_surface=pygame.image.load(join("images","player.png")).convert_alpha()

#20 different random star positions with stars
#star_positions=[(random.randint(0,1280),random.randint(0,720))for i in range(20)]

#plain surface
#surface.fill("maroon")

# laser_rect=laser_surface.get_frect(center=(WINDOW_WIDTH-20,Window_HEIGHT-20))

test_rect=pygame.FRect(0,0,300,600)
#score

while running: 
    dt=clock.tick()/1000 
    #event loop to loop game
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
        if event.type==Meteor_event:
            x,y=random.randint(0,WINDOW_WIDTH),random.randint(-200,-100)
            meteor(Meteor,(x,y),(all_sprites,meteor_sprites))  
              
    '''if event.type==pygame.MOUSEMOTION:
            Plane_rectangle.center= event.pos'''
    
    #fill window with blue color
    
    
    star_sprites.update()
    all_sprites.update(dt)
    
    #display_surface.blit(surface,(x,150))
    
    #Movement bounce
    '''if Plane_rectangle.right>WINDOW_WIDTH or Plane_rectangle.left<0:
        Plane_direct.x*=-1
    if Plane_rectangle.top<0 or Plane_rectangle.bottom>Window_HEIGHT:
        Plane_direct.y*=-1'''
    '''display_surface.blit(Meteor,Meteor_rect)
    display_surface.blit(laser_surface,laser_rect)'''
    collision()
    
    #draw game
    display_surface.fill((23,35,40))
    star_sprites.draw(display_surface)
    all_sprites.draw(display_surface) 
    Numbers_font()
    #test collisions
    pygame.display.update()
    
pygame.quit()